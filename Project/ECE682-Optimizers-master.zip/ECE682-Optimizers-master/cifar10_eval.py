from src.model.model import Model
import keras
import argparse
from src.model.nets.lib import network_lib
from src.core.optimizer import opt_lib
from src.core.utilities import hist_to_metrics
from src.core.utilities import write_to_file
import tensorflow as tf

from keras.backend.tensorflow_backend import set_session
config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.20
set_session(tf.Session(config=config))

# Patch for MAC
import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--lr", nargs='?', type=float, help="Learning rate", default=1e-5)
    parser.add_argument("--reg", nargs='?', type=float, help="Regularizer strength", default=1e-5)
    parser.add_argument("--network", nargs='?', type=str, help="Regularizer strength", default="VGG9")
    parser.add_argument("--optimizer", nargs='?', type=str, help="Optimizer", default='momentum')
    parser.add_argument("--dropout", nargs='?', type=float, help="Dropout for 2 fc layers", default=0.5)
    parser.add_argument("--epochs", nargs='?', type=int, help="Number of epochs", default=100)
    parser.add_argument("--use_da", nargs='?', type=int, help="Use data augmentation or not", default=True)
    parser.add_argument("--use_lr_schedule", nargs='?', type=int, help="Use learning rate schedule or not", default=True)
    parser.add_argument("--logdir", required=True, type=str, help="Logging directory", default="./logs")

    args = parser.parse_args()
    print(vars(args))

    if not os.path.exists(args.logdir):
        os.makedirs(args.logdir)

    model = Model(lr=args.lr, regularizer=keras.regularizers.l2(args.reg),
                  dropout=args.dropout,
                  network=network_lib[args.network],
                  optimizer=opt_lib[args.optimizer])
    model.keras_model.summary()
    data_train, data_val = keras.datasets.cifar10.load_data()

    hist_log = model.fit(data_train, data_val,  epochs=args.epochs, schedule_lr= (args.use_lr_schedule == 1),
                         data_augmentation=(args.use_da == 1))

    val_acc_file = os.path.join(args.logdir, "val_acc.txt")
    val_loss_file = os.path.join(args.logdir, 'val_loss.txt')

    train_acc_file = os.path.join(args.logdir, "train_acc.txt")
    train_loss_file = os.path.join(args.logdir, "train_loss.txt")

    write_to_file(hist_log['acc'], train_acc_file)
    write_to_file(hist_log['loss'], train_loss_file)
    write_to_file(hist_log['val_acc'], val_acc_file)
    write_to_file(hist_log['val_loss'], val_loss_file)