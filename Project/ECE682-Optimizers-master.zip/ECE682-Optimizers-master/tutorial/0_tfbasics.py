import tensorflow as tf
import numpy as np
import argparse
from math import ceil
from tqdm import tqdm

n_size = 1000

def toy_data():
    X = np.random.normal(loc=0.0, scale=1.0, size=[n_size, 2])
    y = 2.5 * X[:,0] - 1.5 * X[:,1] + 3
    y = np.expand_dims(y, axis=1)
    return X, y


def SplitTrainVal(X, y, validation_split=.2):
    np.random.seed()
    N = np.shape(X)[0]
    indices = np.random.permutation(N)
    train_idx = indices[0:int(N*(1-validation_split))]
    val_idx = indices[int(N*(1-validation_split)):]
    X_tr = X[train_idx]
    y_tr = y[train_idx]
    X_val = X[val_idx]
    y_val = y[val_idx]
    return X_tr, y_tr, X_val, y_val


class TFGraph:
    def __init__(self, **kwargs):
        # Input Placeholder
        self.X = None
        self.y = None
        # Neural Network part
        self.W = None  # Weight
        self.b = None  # bias
        self.h = None  # hypothesis
        # Loss function
        self.loss = None
        # optimizer & train_op
        self.optimizer = None
        self.train_op = None
        # Hyperparameters, add more if you'd like to
        self.lr = kwargs['lr']

        # create the computational graph
        self._create_graph()

    def _create_graph(self):
        self.X = tf.placeholder(dtype=tf.float32, shape=[None, 2])
        self.y = tf.placeholder(dtype=tf.float32, shape=[None, 1])
        # Try to change the initializer and regularizer and see what happens
        with tf.variable_scope("W1") as scope:
            self.W = tf.get_variable(name='weights', shape=[2, 1], initializer=None, regularizer=None)
            self.b = tf.get_variable(name='bias', shape=[1], initializer=None, regularizer=None)
            self.h = tf.matmul(self.X, self.W) + self.b

        self.loss = tf.losses.mean_squared_error(self.h, self.y)
        self.loss += tf.losses.get_regularization_loss()
        # Change the optimizer to see the convergence speed
        self.optimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)
        # Compute gradient
        grads_and_vars = self.optimizer.compute_gradients(self.loss)
        # Apply gradient
        self.train_op = self.optimizer.apply_gradients(grads_and_vars)


def main(args):
    sess = tf.InteractiveSession()
    X, y = toy_data()
    # Instantialize the object
    net = TFGraph(lr=args['lr'])
    # Initialize the ops
    sess.run(tf.global_variables_initializer())
    X_tr, y_tr, X_val, y_val = SplitTrainVal(X, y, validation_split=0.2)

    num_train_examples = np.shape(X_tr)[0]
    num_val_examples = np.shape(X_val)[0]

    val_batch_size = 100

    train_steps = ceil(num_train_examples / args['batch_size'])
    val_steps = ceil(num_val_examples / val_batch_size)

    global_steps = 0
    for i in range(args['epochs']):
        print("Epoch %d/%d" %(i+1, args['epochs']))
        for j in range(train_steps):
            indices = np.random.choice(num_train_examples, args['batch_size'])
            X_batch, y_batch = X_tr[indices], y_tr[indices]
            sess.run(net.train_op, feed_dict={net.X: X_batch, net.y: y_batch})
            global_steps += 1

        loss = sess.run(net.loss, feed_dict={net.X: X_tr, net.y: y_tr})
        print("Step %d: MSE loss: %f" %(global_steps, loss))

        val_loss = 0
        for j in range(val_steps):
            X_batch, y_batch = X_val[args['batch_size']*j:args['batch_size']*(j+1)], \
                               y_val[args['batch_size']*j:args['batch_size']*(j+1)]
            val_loss += sess.run(net.loss, feed_dict={net.X: X_batch, net.y: y_batch})
        val_loss /= val_steps
        print("Validation MSE loss: %f" %(val_loss))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    optional = parser._action_groups.pop()
    required = parser.add_argument_group('required arguments')

    optional.add_argument('--lr', type=float,
                          help='Learning rate. Default is 1e-2',
                          default=1e-3)
    optional.add_argument('--batch_size', type=int, nargs='?',
                          help='Training batch size, default is 32.',
                          default=32)
    optional.add_argument('--epochs', type=int, nargs='?',
                          help="Training epochs, default is 10.",
                          default=10)

    parser._action_groups.append(optional)
    args = vars(parser.parse_args())
    print(args)

    main(args)







