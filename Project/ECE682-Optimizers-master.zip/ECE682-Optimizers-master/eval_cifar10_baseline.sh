#!/usr/bin/env bash
python cifar10_eval.py --lr 1e-2 --reg 1e-5 --network VGG9 --optimizer momentum --dropout 0.5 --logdir ./results/baseline/vgg9-momentum-baseline --epochs 50 --use_da 1 --use_lr_schedule 1
python cifar10_eval.py --lr 1e-3 --reg 1e-5 --network VGG9 --optimizer adam --dropout 0.5  --logdir ./results/baseline/vgg9-adam-baseline --epochs 50 --use_da 1 --use_lr_schedule 1
python cifar10_eval.py --lr 1e-2 --reg 1e-5 --network VGG9 --optimizer nesterov --dropout 0.5  --logdir ./results/baseline/vgg9-nesterov-baseline --epochs 50 --use_da 1 --use_lr_schedule 1
python cifar10_eval.py --lr 1e-3 --reg 1e-5 --network VGG9 --optimizer rmsprop --dropout 0.5 --logdir ./results/baseline/vgg9-rmsprop-baseline --epochs 50 --use_da 1 --use_lr_schedule 1