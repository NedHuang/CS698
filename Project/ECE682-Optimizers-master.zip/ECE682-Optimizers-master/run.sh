 python main.py --initial_lr 1e-5 --initial_reg 1e-5 --optimizer adam --dropout 0.1 --network VGG8  --alpha 0.1
