#!/usr/bin/env bash
python cifar10_eval.py --lr 1e-1 --reg 1e-5 --network VGG9 --optimizer momentum --dropout 0.5 --epochs 10 --logdir ./results/eval_lr/vgg9-momentum-1e-1 --epochs 50 --use_da 0 --use_lr_schedule 0
python cifar10_eval.py --lr 1e-2 --reg 1e-5 --network VGG9 --optimizer momentum --dropout 0.5 --epochs 10 --logdir ./results/eval_lr/vgg9-momentum-1e-2 --epochs 50 --use_da 0 --use_lr_schedule 0
python cifar10_eval.py --lr 1e-3 --reg 1e-5 --network VGG9 --optimizer momentum --dropout 0.5 --epochs 10 --logdir ./results/eval_lr/vgg9-momentum-1e-3 --epochs 50 --use_da 0 --use_lr_schedule 0
python cifar10_eval.py --lr 1e-4 --reg 1e-5 --network VGG9 --optimizer momentum --dropout 0.5 --epochs 10 --logdir ./results/eval_lr/vgg9-momentum-1e-4 --epochs 50 --use_da 0 --use_lr_schedule 0
python cifar10_eval.py --lr 1e-5 --reg 1e-5 --network VGG9 --optimizer momentum --dropout 0.5 --epochs 10 --logdir ./results/eval_lr/vgg9-momentum-1e-5 --epochs 50 --use_da 0 --use_lr_schedule 0