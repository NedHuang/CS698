from src.core.layers import *

class VGG16:
    def __init__(self, dropout, regularizer, input_shape=(32, 32, 3)):
        self.dropout_rate = dropout
        self.regularizer = regularizer
        self.input_shape = input_shape

    def __call__(self):
        inputs = keras.layers.Input(shape=self.input_shape)
        net = conv_relu(inputs, filters=64, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=64, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = maxpool(net, pool_size=2, strides=2)

        net = conv_relu(net, filters=128, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=128, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = maxpool(net, pool_size=2, strides=2)

        net = conv_relu(net, filters=256, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=256, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=256, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = maxpool(net, pool_size=2, strides=2)

        net = conv_relu(net, filters=512, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=512, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=512, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = maxpool(net, pool_size=2, strides=2)

        net = conv_relu(net, filters=512, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=512, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = conv_relu(net, filters=512, ksize=3, strides=1,
                        regularizer=self.regularizer)
        net = maxpool(net, pool_size=2, strides=2)

        net = keras.layers.Flatten()(net)

        net = dropout(net, self.dropout_rate)
        net = dense(net, units=512, activation='relu', regularizer=self.regularizer)

        net = dropout(net, self.dropout_rate)
        net = dense(net, units=512, activation='relu', regularizer=self.regularizer)
        
        net = dense(net, units=10, activation='softmax', regularizer=None)

        return keras.models.Model(inputs=inputs, outputs=net)
