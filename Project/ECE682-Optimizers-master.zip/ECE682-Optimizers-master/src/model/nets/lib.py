from src.model.nets.VGG9 import VGG9
from src.model.nets.VGG11 import VGG11
from src.model.nets.VGG16 import VGG16

network_lib = {'VGG9': VGG9,
       "VGG11": VGG11,
       "VGG16": VGG16}

