from src.model.nets.VGG16 import *
import numpy as np
from src.core.optimizer import opt_lib
from src.model.nets.lib import network_lib



class Model:
    def __init__(self, lr, optimizer,
                 dropout=0.0,
                 regularizer=keras.regularizers.l2(1e-4),
                 input_shape=(32, 32, 3),
                 network=network_lib['VGG9'],
                 verbose=False):
        self.lr = lr
        self.optimizer = optimizer
        self.keras_model = network(dropout=dropout, regularizer=regularizer, input_shape=input_shape)()
        self.keras_model.compile(self.optimizer(self.lr), loss=keras.losses.sparse_categorical_crossentropy,
                           metrics=['accuracy'])
        if verbose:
           self.keras_model.summary()

    def fit(self, train_data, val_data, batch_size=128, epochs=20, data_augmentation=False, schedule_lr=False):
        X_tr, y_tr = train_data
        X_val, y_val = val_data

        _mean = np.mean(X_tr, axis=(0, 1, 2))
        _std = np.std(X_tr, axis=(0, 1, 2))

        X_tr = (X_tr - _mean) / _std
        X_val = (X_val - _mean) / _std

        print(np.shape(X_val))
        if not data_augmentation:
            datagen = keras.preprocessing.image.ImageDataGenerator(
                rotation_range=0,
                width_shift_range=0. / 32,
                height_shift_range=0. / 32,
                horizontal_flip=False,
                vertical_flip=False)
            datagen.fit(X_tr, augment=False)
        else:
            datagen = keras.preprocessing.image.ImageDataGenerator(
                rotation_range=0,
                width_shift_range=3. / 32,
                height_shift_range=3. / 32,
                horizontal_flip=True,
                vertical_flip=False)
            datagen.fit(X_tr, augment=True)

        model_checkpoint = keras.callbacks.ModelCheckpoint('./models/model.ckpt', save_best_only=True,
                                                           monitor='val_acc')
        if not schedule_lr:
            hist = self.keras_model.fit_generator(datagen.flow(X_tr, y_tr, batch_size=batch_size),
                                epochs=epochs, steps_per_epoch=len(X_tr) / batch_size,
                                validation_data=(X_val, y_val),
                                callbacks=[model_checkpoint])
        else:
            lr_scheduler = keras.callbacks.ReduceLROnPlateau(monitor='val_acc', patience=5, verbose=1, factor=.1,
                                                             min_lr=1e-5)
            hist = self.keras_model.fit_generator(datagen.flow(X_tr, y_tr, batch_size=batch_size),
                                epochs=epochs, steps_per_epoch=len(X_tr) / batch_size,
                                validation_data=(X_val, y_val),
                                callbacks=[model_checkpoint, lr_scheduler])

        print(hist.history)
        return hist.history

    def close(self):
        keras.backend.clear_session()
        pass
