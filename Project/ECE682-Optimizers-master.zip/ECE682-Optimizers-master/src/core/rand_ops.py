import numpy as np
from math import exp

def sample_openball(x, std_scale):

    rnd = np.random.normal(loc=0.0, scale=std_scale)
    return x * exp(rnd)
