import keras


def adam(lr=4e-3):
    return keras.optimizers.adam(lr=lr,
                                 epsilon=1e-4)


def rmsprop(lr=1e-3, momentum=.9):
    return keras.optimizers.rmsprop(lr=lr,
    rho=momentum)

def sgd_momentum(lr=1e-2, momentum=.9):
    return keras.optimizers.sgd(lr=lr,
                                momentum=momentum,
                                nesterov=False)

def sgd_momentum_nesterov(lr=1e-2, momentum=.9):
    return keras.optimizers.sgd(lr=lr,
                                momentum=momentum,
                                nesterov=True)


opt_lib = {'adam': adam,
           'rmsprop': rmsprop,
           'momentum': sgd_momentum,
           'nesterov': sgd_momentum_nesterov}


