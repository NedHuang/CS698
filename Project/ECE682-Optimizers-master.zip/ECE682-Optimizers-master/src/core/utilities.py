import numpy as np
from math import isnan
import matplotlib.pyplot as plt
import datetime
from math import exp

def is_nan(x):
    return isnan(x) or abs(x) > 1e4

def hist_to_metrics(hist, sort_metric='val_acc', grep_metrics=('val_loss', 'val_acc')):
    """
    Process the history values and get the metrics
    :param hist:
    :return:
    :param sort_metric:
    """
    metrics = {}
    max_id = np.argmax(hist[sort_metric])
    for keys in grep_metrics:
        metrics[keys] = [hist[keys][max_id]]
        for id in range(len(metrics[keys])):
            if is_nan(metrics[keys][id]):
                metrics[keys][id] = 0
    return metrics


def merge_dicts(org_dict, new_dict):
    """
    Merge dict contents
    :param org_dict:
    :param new_dict:
    :return:
    """
    for keys in org_dict.keys():
        assert keys in new_dict.keys(), "Cannot merge two dictionaries with different keys"
        org_dict[keys] += new_dict[keys]
    return org_dict


def add_to_log(fp, hp, perf):
    fp.write("%s\n" %datetime.datetime.now())
    fp.write("%s-->Performance: %s\n" %(hp, perf))


def add_to_graph(perf, graph_meta, graph_path, meta='val_acc', efunc=max):
    graph_meta.append(efunc(perf[meta]))
    n = np.shape(graph_meta)[0]
    plt.figure()
    plt.plot(np.arange(n), graph_meta)
    plt.title("Performance progress vs Iteration")
    plt.xlabel("Iteration")
    plt.ylabel("Performance")
    plt.savefig(graph_path)
    plt.close()

def write_config(cfg, file_path):
    with open(file_path, 'w') as fp:
        for key in cfg.keys():
            fp.write("%s:%s\n" %(key, cfg[key]))


def write_to_file(data, filename):
    with open(filename, 'w') as fp:
        for x in data:
            fp.write("%s\n" %x)