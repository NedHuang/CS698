import tensorflow as tf
import keras

def l2_regularizer(reg=1e-4):
    return keras.regularizers.l2(reg)

def conv_relu(X,
              filters,
              ksize,
              strides=1,
              regularizer=l2_regularizer(1e-3)):
    net = keras.layers.Conv2D(filters=filters,
                              kernel_size=ksize,
                              strides=strides,
                              kernel_regularizer=regularizer,
                              activation='relu',
                              padding='SAME',
                              kernel_initializer=keras.initializers.glorot_normal(571))(X)
    return net


def maxpool(X,
            pool_size=2,
            strides=2):
    net = keras.layers.MaxPool2D(pool_size=pool_size,
                                 strides=strides)(X)
    return net


def global_avgpool(X):
    net = keras.layers.GlobalAvgPool2D()(X)
    return net


def dense(X,
          units,
          activation='relu',
          regularizer=l2_regularizer(1e-3)):
    net = keras.layers.Dense(units=units,
                             activation=activation,
                             kernel_regularizer=regularizer,
                             kernel_initializer=keras.initializers.glorot_normal(571))(X)
    return net


def dropout(X,
            rate):
    net = keras.layers.Dropout(rate=rate)(X)
    return net

