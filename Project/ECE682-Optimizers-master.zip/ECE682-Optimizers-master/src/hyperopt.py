from src.model.model import Model
from src.core.rand_ops import sample_openball
from src.core.layers import l2_regularizer
from src.core.optimizer import opt_lib
from src.core.utilities import *
from src.model.nets.lib import network_lib
from src.core.colors import bcolors
import numpy as np
import os
from math import log


class HyperOpt:
    def __init__(self, cfg, data):
        """
        Initialize HyperOpt Instance with configuration and data
        :param cfg:
        :param data:
        """
        self.global_steps = 0
        self.cfg = {
            'initial_lr': cfg['initial_lr'],
            'initial_reg': cfg['initial_reg'],
            'lr_delta': cfg['lr_delta'],
            'reg_delta': cfg['reg_delta'],
            'alpha': cfg['alpha'],
            'steps': cfg['steps'],
            'async_updates': cfg['async_updates'],
            'tries': cfg['tries'],
            'epochs': cfg['epochs'],
            'log_dir': cfg['log_dir'],
            'update_momentum': cfg['update_momentum'],
            'decay': cfg['decay']
        }
        self.cur_alpha = self.cfg['alpha']
        self.logging_dir = self.cfg['log_dir']
        if not os.path.exists(self.logging_dir):
            os.makedirs(self.logging_dir)
        self.log_fp = open(os.path.join(self.logging_dir, "log.txt"), 'w')

        write_config(self.cfg, os.path.join(self.logging_dir, "config.txt"))

        self.network = cfg['network']

        self.dropout = cfg['dropout']
        self.optimizer = cfg['optimizer']

        self.data = data

        self.async_update_cnt = 10

        self.base_hps = {
            'lr': self.cfg['initial_lr'],
            'reg': self.cfg['initial_reg']
        }
        self.sampled_hps = {
            'lr': self.base_hps['lr'],
            'reg': self.base_hps['reg']
        }

        self.graph_meta = []
        self.base_perf = self.run_one_model()
        add_to_log(self.log_fp, self.base_hps, self.base_perf)
        add_to_graph(self.base_perf, self.graph_meta, os.path.join(self.logging_dir, "performance.png"))

        self.sampled_queue = []
        self.sampled_metrics_queue = []
        self.sampled_grouped_metrics_queue = []

        self.update_values = {}

        self.best_perf = 0

    def sample_new_hp(self):
        self.sampled_hps['lr'] = sample_openball(self.base_hps['lr'], self.cfg['lr_delta'])
        self.sampled_hps['reg'] = sample_openball(self.base_hps['reg'], self.cfg['reg_delta'])
        self.sampled_queue.append({'lr': self.sampled_hps['lr'],
                                   'reg': self.sampled_hps['reg']})
        print(bcolors.OKGREEN + "Sampling hyperparameters: %s" %self.sampled_hps + bcolors.ENDC)

        pass

    def run(self):
        for global_steps in range(self.cfg['steps']):
            print(bcolors.WARNING + "Step %d" %global_steps + bcolors.ENDC)
            self.sample_new_hp()
            metric = self.run_one_model()
            self.sampled_metrics_queue.append(metric)
            if global_steps != 0 and global_steps % self.cfg['async_updates'] == 0:
                self._group_metric_queue()
                self._formulate_update()
                self.apply_update()
                self.sampled_metrics_queue = []
                self.base_perf = self.run_one_model()
                add_to_log(self.log_fp, self.base_hps, self.base_perf)
                add_to_graph(self.base_perf, self.graph_meta, os.path.join(self.logging_dir, "performance.png"))

            pass

    def run_one_model(self):
        """
        Run one model with given hyperparameters multiple times.
        :param tries: times to run the model
        :return: metrics
        """
        metrics = None
        for i in range(self.cfg['tries']):
            model = Model(lr=self.sampled_hps['lr'],
                          regularizer=l2_regularizer(self.sampled_hps['reg']),
                          dropout=self.dropout,
                          network=network_lib[self.network],
                          optimizer=opt_lib[self.optimizer],
                          verbose=(i == 0))
            hist = model.fit(self.data['train'],
                             self.data['val'],
                             epochs=self.cfg['epochs'])
            metric = hist_to_metrics(hist)
            if metrics is None:
                metrics = metric
            else:
                metrics = merge_dicts(metrics, metric)
            model.close()
        return metrics

    def _group_metric_queue(self):
        """
        Group the metrics in metric_queue and get the statistic mean and variance
        :return:
        """
        self.sampled_grouped_metrics_queue = []
        for i in range(len(self.sampled_metrics_queue)):
            new_item_dict = {}
            for keys in self.sampled_metrics_queue[i]:
                _mean_feature = "%s_mean" %keys
                _std_feature = "%s_std" %keys
                new_item = {_mean_feature: np.mean(self.sampled_metrics_queue[i][keys]),
                            _std_feature: np.std(self.sampled_metrics_queue[i][keys])}
                new_item_dict.update(new_item)
            self.sampled_grouped_metrics_queue.append(new_item_dict)

    def _formulate_update(self):
        """
        Formulate the update function within the metrics queue
        :return:
        """
        for key in self.sampled_queue[0].keys():
            if not key in self.update_values:
                self.update_values[key] = 0.
            else:
                self.update_values[key] = self.update_values[key] * self.cfg['update_momentum']

        perf_key = "val_acc"
        group_key = "val_acc_mean"
        print(self.sampled_grouped_metrics_queue)

        for i in range(len(self.sampled_queue)):
            for key in self.sampled_queue[i].keys():
                upd_value = (self.sampled_grouped_metrics_queue[i][group_key]-self.base_perf[perf_key][0])\
                            / (log(self.sampled_queue[i][key]) - log(self.base_hps[key]))
                self.update_values[key] += self.cur_alpha * upd_value / len(self.sampled_queue)
        # Do gradient ascent
        pass

    def apply_update(self):
        """
        Apply the update to all of the hyper-parameters
        :return:
        """
        print(self.update_values)
        for key in self.update_values.keys():
            self.base_hps[key] *= exp(self.update_values[key])
        print(bcolors.OKBLUE + "Hyperparameter updated to %s" %self.base_hps + bcolors.ENDC)
        # Decay alpha
        self.cur_alpha *= self.cfg['decay']
        print(bcolors.WARNING + "Alpha is decayed to %f" %self.cur_alpha + bcolors.ENDC)
        # Clean up
        self.sampled_queue = []
        self.sampled_metrics_queue = []
        self.sampled_grouped_metrics_queue = []
