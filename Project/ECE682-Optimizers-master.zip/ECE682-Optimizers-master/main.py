import argparse
import keras
from src.hyperopt import HyperOpt
import tensorflow as tf

from keras.backend.tensorflow_backend import set_session
config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.20
set_session(tf.Session(config=config))

def subdataset(data, num=1000):
    return data[0][:num], data[1][:num]

def main(args, cfg=None):
    data = {}
    data_tr, data_val = keras.datasets.cifar10.load_data()
    #data_tr = subdataset(data_tr, num=10000)
    #data_val = subdataset(data_val, num=2000)

    data['train'] = data_tr
    data['val'] = data_val

    hyperopt = HyperOpt(cfg=cfg, data=data)
    hyperopt.run()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    optional = parser._action_groups.pop()
    required = parser.add_argument_group("required arguments")

    required.add_argument("--initial_lr", required=True, type=float,
                          help="Initial learning rate.")
    required.add_argument("--initial_reg", required=True, type=float,
                          help="Initial regularization term")
    required.add_argument("--optimizer", required=True, type=str,
                          help="Optimizer")
    required.add_argument("--dropout", required=True, type=float,
                          help="Dropout for final 2 fc layers.")
    required.add_argument("--network", required=True, type=str,
                          help="Model to evaluate. Default is VGG9",
                          default="VGG9")
    required.add_argument('--alpha', required=True, type=float,
                          help="Hyperopt update rate.")
    optional.add_argument("--lr_delta", type=float, nargs='?',
                          help="Learning rate fluctation delta",
                          default=0.5)
    optional.add_argument("--reg_delta", type=float, nargs='?',
                          help="Learning rate fluctation delta",
                          default=0.05)
    optional.add_argument('--steps', type=int, nargs='?',
                          help="Hyperopt steps",
                          default=1000)
    optional.add_argument('--async_updates', type=int, nargs='?',
                          help='Asynchronous update number',
                          default=5)
    optional.add_argument('--tries', type=int, nargs='?',
                          help='tries to evaluate a set of hyperparameters',
                          default=2)
    optional.add_argument('--epochs', type=int, nargs='?',
                          help='Epochs for each model training',
                          default=10)
    optional.add_argument('--log_dir', type=str, nargs='?',
                          help="Logging directory",
                          default="./log.txt")
    optional.add_argument("--update_momentum", type=float, nargs='?',
                          help="Update momentum",
                          default=0.9)
    optional.add_argument("--decay", type=float, nargs='?',
                          help="meta-learning rate decay",
                          default=.95)
    parser._action_groups.append(optional)
    args = vars(parser.parse_args())
    print(args)

    cfg = {'initial_lr': args['initial_lr'],
           'initial_reg': args['initial_reg'],
           'optimizer': args['optimizer'],
           'dropout': args['dropout'],
           'lr_delta': args['lr_delta'],
           'reg_delta': args['reg_delta'],
           'alpha': args['alpha'],
           'async_updates': args['async_updates'],
           'steps': args['steps'],
           'tries': args['tries'],
           'network': args['network'],
           'epochs': args['epochs'],
           'log_dir': args['log_dir'],
           'update_momentum': args['update_momentum'],
           'decay': args['decay']
           }

    main(args, cfg)
