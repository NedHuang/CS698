./run_nesterov.sh
./run_momentum.sh
./run_adam.sh
./run_rmsprop.sh