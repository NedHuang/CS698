CUDA_VISIBLE_DEVICES=0 python train.py \
        --maxlen1 100 \
        --maxlen2 100 \
        --d_model 256 \
        --d_ff 512 \
        --lr 3e-4 \
        --num_epochs 20 \
        --logdir ./ckpt_transformer_100_256_512 | tee train_logs/transformer_100_256_512.log