CUDA_VISIBLE_DEVICES=1 python train.py \
        --maxlen1 100 \
        --maxlen2 100 \
        --d_model 512 \
        --d_ff 1024 \
        --lr 3e-4 \
        --num_epochs 20 \
        --logdir ./ckpt_transformer_100_512_1024 | tee train_logs/transformer_100_512_1024.log