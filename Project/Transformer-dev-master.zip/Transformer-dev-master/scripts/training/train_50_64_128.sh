CUDA_VISIBLE_DEVICES=0 python train.py \
        --maxlen1 50 \
        --maxlen2 50 \
        --d_model 64 \
        --d_ff 128 \
        --lr 5e-4 \
        --num_epochs 20 \
        --logdir ./ckpt_transformer_50_64_128 | tee train_logs/transformer_50_64_128.log