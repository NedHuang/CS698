CUDA_VISIBLE_DEVICES=0 python train.py \
        --maxlen1 100 \
        --maxlen2 100 \
        --d_model 128 \
        --d_ff 256 \
        --lr 5e-4 \
        --num_epochs 20 \
        --logdir ./ckpt_transformer_100_128_256 | tee train_logs/transformer_100_128_256.log