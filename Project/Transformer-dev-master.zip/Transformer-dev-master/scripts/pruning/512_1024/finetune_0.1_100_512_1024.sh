CUDA_VISIBLE_DEVICES=1 python -u prune_train.py \
    --sparsity 0.1 \
    --num_epochs 5 \
    --ckpt ./ckpt_transformer_100_512_1024 \
    --maxlen1 100 \
    --maxlen2 100 \
    --d_model 512 \
    --d_ff 1024 \
    --lr 3e-5 \
    --logdir ./ckpt_prune-0.1-ff_transformer_100_512_1024 | tee pruned_logs/transformer_100_512_1024_0.1.log
