./scripts/pruning/512_1024/finetune_0.1_100_512_1024.sh
./scripts/pruning/512_1024/finetune_0.25_100_512_1024.sh
./scripts/pruning/512_1024/finetune_0.5_100_512_1024.sh
./scripts/pruning/512_1024/finetune_0.75_100_512_1024.sh
./scripts/pruning/512_1024/finetune_0.9_100_512_1024.sh
./scripts/pruning/512_1024/finetune_0.95_100_512_1024.sh