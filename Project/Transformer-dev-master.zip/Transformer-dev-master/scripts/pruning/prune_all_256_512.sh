./scripts/pruning/256_512/finetune_0.1_100_256_512.sh
./scripts/pruning/256_512/finetune_0.25_100_256_512.sh
./scripts/pruning/256_512/finetune_0.5_100_256_512.sh
./scripts/pruning/256_512/finetune_0.75_100_256_512.sh
./scripts/pruning/256_512/finetune_0.9_100_256_512.sh
./scripts/pruning/256_512/finetune_0.95_100_256_512.sh