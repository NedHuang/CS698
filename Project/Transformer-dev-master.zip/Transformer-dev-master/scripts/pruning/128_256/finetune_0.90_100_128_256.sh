CUDA_VISIBLE_DEVICES=1 python -u prune_train.py \
    --sparsity 0.90 \
    --num_epochs 5 \
    --ckpt ./ckpt_transformer_100_128_256 \
    --maxlen1 100 \
    --maxlen2 100 \
    --d_model 128 \
    --d_ff 256 \
    --lr 5e-5 \
    --logdir ./ckpt_prune-0.90-ff_transformer_100_128_256 | tee pruned_logs/transformer_100_128_256_0.90.log