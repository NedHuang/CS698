./scripts/pruning/128_256/finetune_0.1_100_128_256.sh
./scripts/pruning/128_256/finetune_0.25_100_128_256.sh
./scripts/pruning/128_256/finetune_0.5_100_128_256.sh
./scripts/pruning/128_256/finetune_0.75_100_128_256.sh
./scripts/pruning/128_256/finetune_0.9_100_128_256.sh
./scripts/pruning/128_256/finetune_0.95_100_128_256.sh