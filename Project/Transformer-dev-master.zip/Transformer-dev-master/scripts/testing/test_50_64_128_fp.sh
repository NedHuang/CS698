# Testing transformer with --maxlen=100, --d_model=128, --ff=256 setup.

CUDA_VISIBLE_DEVICES=0 python test.py \
    --ckpt ./ckpt_transformer_50_64_128/ \
    --maxlen1 50 \
    --maxlen2 50 \
    --d_model 64 \
    --d_ff 128 \
    --testdir ./results/_full_precision_transformer_50_64_128