#!/usr/bin/env bash
./scripts/testing/512_1024/test_prune_ff_100_512_1024_fp-0.1.sh
./scripts/testing/512_1024/test_prune_ff_100_512_1024_fp-0.25.sh
./scripts/testing/512_1024/test_prune_ff_100_512_1024_fp-0.5.sh
./scripts/testing/512_1024/test_prune_ff_100_512_1024_fp-0.75.sh
./scripts/testing/512_1024/test_prune_ff_100_512_1024_fp-0.9.sh
./scripts/testing/512_1024/test_prune_ff_100_512_1024_fp-0.95.sh
