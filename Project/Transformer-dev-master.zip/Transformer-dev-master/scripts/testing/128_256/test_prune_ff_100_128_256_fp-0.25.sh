# Testing transformer with --maxlen=100, --d_model=128, --ff=256 setup.

CUDA_VISIBLE_DEVICES=0 python test.py \
    --ckpt ./ckpt_prune-0.25-ff_transformer_100_128_256/ \
    --maxlen1 100 \
    --maxlen2 100 \
    --d_model 128 \
    --d_ff 256 \
    --testdir ./results/_prune0.25-ff_transformer_100_128_256