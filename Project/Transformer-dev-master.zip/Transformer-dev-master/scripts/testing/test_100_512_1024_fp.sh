# Testing transformer with --maxlen=100, --d_model=128, --ff=256 setup.

CUDA_VISIBLE_DEVICES=1 python test.py \
    --ckpt ./ckpt_transformer_100_512_1024/ \
    --maxlen1 100 \
    --maxlen2 100 \
    --d_model 512 \
    --d_ff 1024 \
    --testdir ./results/_full_precision_transformer_100_512_1024