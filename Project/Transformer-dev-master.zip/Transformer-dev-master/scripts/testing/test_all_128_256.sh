#!/usr/bin/env bash
./scripts/testing/128_256/test_prune_ff_100_128_256_fp-0.1.sh
./scripts/testing/128_256/test_prune_ff_100_128_256_fp-0.25.sh
./scripts/testing/128_256/test_prune_ff_100_128_256_fp-0.5.sh
./scripts/testing/128_256/test_prune_ff_100_128_256_fp-0.75.sh
./scripts/testing/128_256/test_prune_ff_100_128_256_fp-0.9.sh
./scripts/testing/128_256/test_prune_ff_100_128_256_fp-0.95.sh
