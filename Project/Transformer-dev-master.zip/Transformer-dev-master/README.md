[Requirements]
Please run 'pip -r requirements.txt' to install all of the requirements.
[Preliminary steps]
Please run ./download.sh to download the Corpus.
Please run python prepro.py to do the preprocessing.

Please run all of the scripts in the scripts folder to reproduce the results.